enum NutritionGoal { maintenance, fatLoss, hypertrophy }

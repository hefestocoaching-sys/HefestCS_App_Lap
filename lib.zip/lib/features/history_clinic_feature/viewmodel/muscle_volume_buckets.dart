// Exportamos la entidad de dominio para evitar duplicidad de tipos
export 'package:hcs_app_lap/domain/entities/muscle_volume_buckets.dart';

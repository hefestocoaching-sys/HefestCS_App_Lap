enum LengthBias { shortened, mid, lengthened }

enum MechanicProfile { compound, isolation }

enum PainContext { none, occasional, movementSpecific, loadDependent, chronic }

enum RecoveryStatus { veryLow, low, moderate, high }

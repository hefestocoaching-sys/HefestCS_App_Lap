enum LimitingFactor { none, mobility, stability, strength, coordination }

enum AdaptationAggressiveness { conservative, moderate, aggressive }

enum StimulusQuality { veryLow, low, adequate, high, excessive }

class DbConstants {
  static const tableClients = 'clients';
  static const colId = 'id';
  static const colData = 'data';
  static const colUpdatedAt = 'updatedAt';

  // Tabla foods (si la usas)
  static const String tableFoods = 'foods';
}

class NutrientIds {
  static const kcal = 1008;
  static const protein = 1003;
  static const carbs = 1005;
  static const fat = 1004;
}

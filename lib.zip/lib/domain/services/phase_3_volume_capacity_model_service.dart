// lib/domain/services/phase_3_volume_capacity_model_service.dart

/// FACHADA LEGACY para compatibilidad con tests antiguos.
class Phase3VolumeCapacityModelService {
  const Phase3VolumeCapacityModelService();
}

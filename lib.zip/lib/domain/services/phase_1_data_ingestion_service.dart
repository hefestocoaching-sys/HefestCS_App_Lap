// lib/domain/services/phase_1_data_ingestion_service.dart

/// FACHADA LEGACY para compatibilidad con tests antiguos.
class Phase1DataIngestionService {
  const Phase1DataIngestionService();
}

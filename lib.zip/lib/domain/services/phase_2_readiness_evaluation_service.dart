// lib/domain/services/phase_2_readiness_evaluation_service.dart

/// FACHADA LEGACY para compatibilidad con tests antiguos.
enum ReadinessLevel { low, moderate, high }

class Phase2ReadinessEvaluationService {
  const Phase2ReadinessEvaluationService();
}
